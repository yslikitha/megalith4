# ML_frontend

Megalith Internship Site Frontend Repository

Things done: 
✅ Page basic body
✅ Header, navbar, footer
✅ Home section with image slides
✅ Brochure section with video iframe
✅ Incentives section with image cards of monuments and titles 
✅ Smooth scroll

Todo:
🔳 Parallax Effect on the page
🔳 Responsibilities section
🔳 Hamburger menu
🔳 SignUp/Sign In Page
🔳 New and creative ideas with the incentives and responsibilities section
🔳 MIP text with Monument texts 